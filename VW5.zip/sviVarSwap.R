  # Computes var swaps for given vector of expirations

sviVarSwap <- function(sviMatrix,texp){
  
  nSlices <- length(texp)
  varRes <- numeric(nSlices)
 
  for (slice in 1:nSlices){
    
    t <- texp[slice]
    volBS <- function(k){sqrt(svi(sviMatrix[slice,],k)/t)}
    # cTilde <- function(k){BSFormula(1, exp(k), t, r=0, volBS(k))*exp(-k)}
    # pTilde <- function(k){BSFormulaPut(1, exp(k), t, r=0, volBS(k))*exp(-k)}
    cTilde <- function(y){BSFormula(1, 1/y, t, r=0, volBS(-log(y)))}
    pTilde <- function(y){BSFormulaPut(1, y, t, r=0, volBS(log(y)))/y^2}
    callIntegral <- integrate(cTilde,lower=0,upper=1)$value
    putIntegral <- integrate(pTilde,lower=0,upper=1)$value
    varRes[slice] <- 2*(callIntegral+putIntegral)/t # Equation (11.4) of TVS
  }
  return(varRes)  # Returns vector of variance swaps in variance (vol. squared) terms
}

# vols <- sqrt(sviVarSwap(sviMatrix,texp))
# plot(texp,vols)